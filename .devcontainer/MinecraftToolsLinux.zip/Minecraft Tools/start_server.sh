cd server
java -Xms512M -Xmx1024M -jar spigot-1.16.3.jar -o true

